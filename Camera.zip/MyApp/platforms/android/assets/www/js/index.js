var Image = null;

function init() {
  document.addEventListener("deviceready", onDeviceReady, false);
}

function onDeviceReady() {
  document.getElementById("btn_share").addEventListener("click", function(){
    if(Image){
      window.plugins.socialsharing.share(null, 'Android filename', Image, null)
    }

    //window.socialmessage.send(message);
  })
}

function capturePhoto() {
  var options = {
    quality: 50,
    destinationType: Camera.DestinationType.DATA_URL,
    encodingType: Camera.EncodingType.JPEG,
    saveToPhotoAlbum: true
  };

  navigator.camera.getPicture(onPhotoSuccess, onPhotoFail, options);
}

function onPhotoSuccess(imageData) {
  var myImage = document.getElementById('myImage');
  Image = "data:image/jpeg;base64,"+imageData
  myImage.style.display = 'block';
  myImage.src = Image;
}

function onPhotoFail(message) {
  alert('Failed because: ' + message);
}

function pickPhoto() {
  var options = {
    destinationType: Camera.DestinationType.DATA_URL,
    encodingType: Camera.EncodingType.JPEG,
    sourceType: Camera.PictureSourceType.PHOTOLIBRARY
  };

  navigator.camera.getPicture(onSelectSuccess, onSelectFail, options);
}

function onSelectSuccess(imageData) {
  var myImage = document.getElementById('myImage');
  Image = "data:image/jpeg;base64,"+imageData
  myImage.src = Image;
}

function onSelectFail(message) {

}
